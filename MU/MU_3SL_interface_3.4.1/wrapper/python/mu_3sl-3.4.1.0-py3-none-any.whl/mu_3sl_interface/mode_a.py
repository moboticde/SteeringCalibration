# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntEnum, unique


@unique
class ModeA(IntEnum):
    SPI_TRI = 0
    SPI = 1
    BISS = 2
    ABZ = 3
    SSI = 4
    SSI_ERRL = 5
    SSI_ERRH = 6
    EXT_SSI = 7
