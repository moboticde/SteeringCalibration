# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntFlag, unique


@unique
class CalibrationAnalyzeResultLogLevel(IntFlag):
    ERRORS = 1
    WARNINGS = 2
    NOTE = 4
    ALL = (ERRORS | WARNINGS | NOTE)
