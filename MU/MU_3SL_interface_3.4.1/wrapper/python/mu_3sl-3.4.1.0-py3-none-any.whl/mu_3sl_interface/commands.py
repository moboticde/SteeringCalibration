# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntEnum, unique, auto


@unique
class Command(IntEnum):
    NO_FUNCTION = 0
    WRITE_ALL = auto()
    WRITE_OFF = auto()
    ABS_RESET = auto()
    NON_VER = auto()
    MT_RESET = auto()
    MT_VER = auto()
    SOFT_RESET = auto()
    SOFT_PRES = auto()
    SOFT_E2P_PRES = auto()
    I2C_COM = auto()
    EVENT_COUNT = auto()
    SWITCH = auto()
    CRC_VER = auto()
    CRC_CALC = auto()
    SET_MTC = auto()
    RES_MTC = auto()
    MODEA_SPI = 18
    ROT_POS = auto()
    ROT_POS_E2P = auto()
