# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

import os
import sys
import platform
from ctypes import *
from packaging import version

# Version of the wrapped MU_3SL_interface shared library
mu_3sl_interface_lib_version = "3.4.1.0"

version_parts = version.parse(mu_3sl_interface_lib_version)

version_major = version_parts.major
version_minor = version_parts.minor
version_path = version_parts.micro

lib_name_version_suffix = '{}.{}.{}'.format(version_major, version_minor, version_path)

shared_library_file_path = None

if platform.system() == 'Linux':
    architecture_path = ''
    if platform.machine() == 'x86_64':
        architecture_path = '/x86_64'
    elif platform.machine() == 'i686':
        architecture_path = '/i686'
    elif platform.machine() == 'aarch64' and platform.architecture()[0] == '32bit':
        architecture_path = '/armhf'
    elif platform.machine() == 'aarch64':
        architecture_path = '/aarch64'
    elif platform.machine() == 'armhf':
        architecture_path = '/armhf'
    elif platform.machine() == 'armv7l':
        architecture_path = '/armhf'
    shared_library_file_path = 'linux{}/libMU_3SL_interface.so.{}'.format(architecture_path, lib_name_version_suffix)
elif platform.system() == 'Darwin':
    shared_library_file_path = 'macOS/universal/libMU_3SL_interface.{}.dylib'.format(
        lib_name_version_suffix)
elif platform.system() == 'Windows':
    if sizeof(c_void_p) == 8:
        shared_library_file_path = 'windows/x86-64/MU_3SL_interface_64.dll'
    else:
        shared_library_file_path = 'windows/x86/MU_3SL_interface.dll'

if shared_library_file_path is None:
    raise RuntimeError('OS platform not supported!')

current_path = os.path.dirname(os.path.abspath(__file__))
shared_library = cdll.LoadLibrary(
    current_path + '/bin/' + shared_library_file_path)

shared_library.MU_GetVersionMajor.restype = c_uint16
shared_library.MU_GetVersionMinor.restype = c_uint16
shared_library.MU_GetVersionPatch.restype = c_uint16
shared_library.MU_GetVersionBuild.restype = c_uint32
shared_library.MU_GetVersionString.restype = c_char_p
shared_library.MU_GetVersionSuffixString.restype = c_char_p


class Library:
    version = (
        shared_library.MU_GetVersionMajor(),
        shared_library.MU_GetVersionMinor(),
        shared_library.MU_GetVersionPatch(),
        shared_library.MU_GetVersionBuild()
    )

    version_string = shared_library.MU_GetVersionString().decode("ascii")
    version_suffix_string = shared_library.MU_GetVersionSuffixString().decode("ascii")

    def __str__(self):
        return self.version_string + self.version_suffix_string
