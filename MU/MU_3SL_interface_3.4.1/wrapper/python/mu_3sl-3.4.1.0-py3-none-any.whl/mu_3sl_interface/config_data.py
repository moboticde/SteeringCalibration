# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntEnum, unique, auto


@unique
class ConfigData(IntEnum):
    FREQ_SPI = 1
    MASTERVER = auto()
    MASTERREV = auto()
    SLAVE_ID = auto()
    FREQ_SCD = auto()
    CLKENI = auto()
    FREQ_AGS = auto()
    SLAVE_COUNT = auto()
    START_CONTROL_FRAME = auto()
    REG_END = auto()
    FREQ_SSI = auto()
    READ_STATUS_ENABLE = auto()
    USB_PERFORMANCE = auto()
    READ_GAIN_ENABLE = auto()
    BP = auto()
    UPDATE_BISSID_ENABLE = auto()
    ENABLE_TTL = auto()
