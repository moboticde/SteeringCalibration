# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntEnum, unique, auto


@unique
class Interface(IntEnum):
    NO_INTERFACE = 0
    MB3U_SPI = auto()
    MB3U_BISS = auto()
    MB4U = auto()
    MB5U = auto()
    MB8U_BISS = auto()
    MB8U_SPI = auto()
