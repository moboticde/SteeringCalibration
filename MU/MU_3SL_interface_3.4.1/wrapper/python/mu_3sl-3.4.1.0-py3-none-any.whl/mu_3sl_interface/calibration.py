# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from ctypes import *
import math
from . import lib_mu_3sl_interface
from . import revisions
from . import units
from . import adjustment_message_log_level
from . import calibration_analyze_result_log_level

Revision = revisions.Revision
Unit = units.Unit
AdjustmentMessageLogLevel = adjustment_message_log_level.AdjustmentMessageLogLevel
CalibrationAnalyzeResultLogLevel = calibration_analyze_result_log_level.CalibrationAnalyzeResultLogLevel

shared_library = lib_mu_3sl_interface.shared_library


class TrackErrors(Structure):
    _fields_ = [("cosine_offset", c_double),
                ("sine_offset", c_double),
                ("amplitude", c_double),
                ("phase", c_double)]

    def get_dict(self):
        return dict((f, getattr(self, f)) for f, _ in self._fields_)


class RelativeAnalogTrackAdjustments(Structure):
    _fields_ = [("cosine_gain_lsb", c_double),
                ("sine_offset_lsb", c_double),
                ("cosine_offset_lsb", c_double),
                ("phase_lsb", c_double)]

    def get_dict(self):
        return dict((f, getattr(self, f)) for f, _ in self._fields_)


class AnalogTrackAdjustments(Structure):
    _fields_ = [("cosine_gain", c_uint8),
                ("sine_offset", c_uint8),
                ("cosine_offset", c_uint8),
                ("phase", c_uint8),
                ("phase_range", c_uint8)]

    def get_dict(self):
        return dict((f, getattr(self, f)) for f, _ in self._fields_)


class NoniusTrackOffsetTable(Structure):
    _fields_ = [("spo_base", c_int8),
                ("spo_n", c_int8 * 16)]

    def __getitem__(self, key):
        if key == 0:
            return self.spo_base
        return self.spo_n[key - 1]

    def __setitem__(self, key, value):
        if key == 0:
            self.spo_base = value
            return
        self.spo_n[key - 1] = value

    def __len__(self):
        return 1 + 16


class NoniusTrackOffsetTableParameters(Structure):
    _fields_ = [("spo_base", c_uint8),
                ("spo_n", c_uint8 * 15)]

    def __getitem__(self, key):
        if key == 0:
            return self.spo_base
        return self.spo_n[key - 1]

    def __setitem__(self, key, value):
        if key == 0:
            self.spo_base = value
            return
        self.spo_n[key - 1] = value

    def __len__(self):
        return 1 + 15


shared_library.MU_isChipRevisionSupported.restype = c_bool
shared_library.MU_isChipRevisionSupported.argtypes = [c_uint8]

shared_library.MU_createCalibration.restype = c_void_p
shared_library.MU_createCalibration.argtypes = [c_uint8]

shared_library.MU_Calibration_delete.argtypes = [c_void_p]

shared_library.MU_Calibration_preconfigureNumberOfMasterPeriods.restype = c_bool
shared_library.MU_Calibration_preconfigureNumberOfMasterPeriods.argtypes = [c_void_p, c_uint]

shared_library.MU_Calibration_analyzeRawData.restype = c_void_p
shared_library.MU_Calibration_analyzeRawData.argtypes = [c_void_p, c_void_p, c_void_p, c_size_t]

shared_library.MU_CalibrationAnalyzeResult_delete.argtypes = [c_void_p]

shared_library.MU_Calibration_getAnalyzeResultLog.restype = c_size_t
shared_library.MU_Calibration_getAnalyzeResultLog.argtypes = [
    c_void_p, c_char_p, c_size_t, c_uint]
shared_library.MU_Calibration_isAnalogAnalysesValid.restype = c_bool
shared_library.MU_Calibration_isAnalogAnalysesValid.argtypes = [c_void_p]

shared_library.MU_Calibration_getRelativeMasterTrackAdjustments.argtypes = [
    c_void_p, POINTER(RelativeAnalogTrackAdjustments)]
shared_library.MU_Calibration_getRelativeNoniusTrackAdjustments.argtypes = [
    c_void_p, POINTER(RelativeAnalogTrackAdjustments)]
shared_library.MU_Calibration_numberOfCalculatedMasterPeriods.restype = c_int
shared_library.MU_Calibration_numberOfCalculatedMasterPeriods.argtypes = [c_void_p]
shared_library.MU_Calibration_numberOfRevolutions.restype = c_double
shared_library.MU_Calibration_numberOfRevolutions.argtypes = [c_void_p]
shared_library.MU_Calibration_numberOfAcquiredMasterPeriods.restype = c_double
shared_library.MU_Calibration_numberOfAcquiredMasterPeriods.argtypes = [c_void_p]
shared_library.MU_Calibration_averageNumberOfSamplesPerMasterPeriod.restype = c_double
shared_library.MU_Calibration_averageNumberOfSamplesPerMasterPeriod.argtypes = [c_void_p]
shared_library.MU_Calibration_minimalNumberOfSamplesPerMasterPeriod.restype = c_double
shared_library.MU_Calibration_minimalNumberOfSamplesPerMasterPeriod.argtypes = [c_void_p]
shared_library.MU_Calibration_getOptimizedNoniusTrackOffsetTable.argtypes = [
    c_void_p, POINTER(NoniusTrackOffsetTable)]
shared_library.MU_Calibration_numberOfNoniusCurveSamples.restype = c_size_t
shared_library.MU_Calibration_numberOfNoniusCurveSamples.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusPhaseError.restype = POINTER(c_long)
shared_library.MU_Calibration_noniusPhaseError.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusTrackOffsetCurve.restype = POINTER(c_long)
shared_library.MU_Calibration_noniusTrackOffsetCurve.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusPhaseMargin.restype = POINTER(c_long)
shared_library.MU_Calibration_noniusPhaseMargin.argtypes = [c_void_p]
shared_library.MU_Calibration_calculateNoniusPosition.restype = c_size_t
shared_library.MU_Calibration_calculateNoniusPosition.argtypes = [c_void_p, c_void_p, c_size_t, c_int, c_bool]
shared_library.MU_Calibration_noniusPhaseMarginMax.restype = c_long
shared_library.MU_Calibration_noniusPhaseMarginMax.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusPhaseMarginMin.restype = c_long
shared_library.MU_Calibration_noniusPhaseMarginMin.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusPhaseRangeLimit.restype = c_long
shared_library.MU_Calibration_noniusPhaseRangeLimit.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusUpperPhaseMargin.restype = c_double
shared_library.MU_Calibration_noniusUpperPhaseMargin.argtypes = [c_void_p]
shared_library.MU_Calibration_noniusLowerPhaseMargin.restype = c_double
shared_library.MU_Calibration_noniusLowerPhaseMargin.argtypes = [c_void_p]

shared_library.MU_Calibration_calculateStPosition.restype = c_size_t
shared_library.MU_Calibration_calculateStPosition.argtypes = [
    c_void_p, c_void_p, c_size_t, c_int, c_bool, POINTER(NoniusTrackOffsetTable)]


class AnalyzeResult:
    """iC-MU Series Calibration Analyze Result"""

    def __init__(self, calibration_analyze_result_handle: c_void_p):
        self.handle = calibration_analyze_result_handle

    def __del__(self):
        shared_library.MU_CalibrationAnalyzeResult_delete(self.handle)

    def log(self, log_level: int) -> str:
        message_buffer_size = shared_library.MU_Calibration_getAnalyzeResultLog(
            self.handle, None, 0, log_level) + 1
        message_buffer_c = create_string_buffer(message_buffer_size)
        r = shared_library.MU_Calibration_getAnalyzeResultLog(
            self.handle, message_buffer_c, message_buffer_size, log_level)
        return message_buffer_c.value.decode('utf-8')

    def is_analog_analyses_valid(self) -> bool:
        r = shared_library.MU_Calibration_isAnalogAnalysesValid(self.handle)
        return r

    def relative_master_track_adjustments(self) -> RelativeAnalogTrackAdjustments:
        relative_analog_track_adjustments = RelativeAnalogTrackAdjustments()
        shared_library.MU_Calibration_getRelativeMasterTrackAdjustments(
            self.handle,
            pointer(relative_analog_track_adjustments))
        return relative_analog_track_adjustments

    def relative_nonius_track_adjustments(self) -> RelativeAnalogTrackAdjustments:
        relative_analog_track_adjustments = RelativeAnalogTrackAdjustments()
        shared_library.MU_Calibration_getRelativeNoniusTrackAdjustments(
            self.handle,
            pointer(relative_analog_track_adjustments))
        return relative_analog_track_adjustments

    def number_of_calculated_master_periods(self) -> int:
        r = shared_library.MU_Calibration_numberOfCalculatedMasterPeriods(self.handle)
        return r

    def number_of_revolutions(self) -> float:
        r = shared_library.MU_Calibration_numberOfRevolutions(self.handle)
        return r

    def number_of_acquired_master_periods(self) -> float:
        r = shared_library.MU_Calibration_numberOfAcquiredMasterPeriods(self.handle)
        return r

    def average_number_of_samples_per_master_period(self) -> float:
        r = shared_library.MU_Calibration_averageNumberOfSamplesPerMasterPeriod(self.handle)
        return r

    def minimal_number_of_samples_per_master_period(self) -> float:
        r = shared_library.MU_Calibration_minimalNumberOfSamplesPerMasterPeriod(self.handle)
        return r

    def optimized_nonius_track_offset_table(self) -> NoniusTrackOffsetTable:
        nonius_track_offset_table = NoniusTrackOffsetTable()
        shared_library.MU_Calibration_getOptimizedNoniusTrackOffsetTable(
            self.handle, pointer(nonius_track_offset_table))
        return nonius_track_offset_table

    def nonius_phase_errors(self) -> list:
        number_of_samples = shared_library.MU_Calibration_numberOfNoniusCurveSamples(
            self.handle)
        nonius_phase_error_p = shared_library.MU_Calibration_noniusPhaseError(self.handle)
        r = [nonius_phase_error_p[i] for i in range(number_of_samples)]
        return r

    def nonius_track_offset_curve(self) -> list:
        number_of_samples = shared_library.MU_Calibration_numberOfNoniusCurveSamples(
            self.handle)
        nonius_track_offset_curve_p = shared_library.MU_Calibration_noniusTrackOffsetCurve(
            self.handle)
        r = [nonius_track_offset_curve_p[i] for i in range(number_of_samples)]
        return r

    def nonius_phase_margin(self) -> list:
        number_of_samples = shared_library.MU_Calibration_numberOfNoniusCurveSamples(
            self.handle)
        nonius_phase_margin_p = shared_library.MU_Calibration_noniusPhaseMargin(self.handle)
        r = [nonius_phase_margin_p[i] for i in range(number_of_samples)]
        return r

    def nonius_position(self,
                        unit: Unit,
                        continuous: bool = False) -> list:
        number_of_samples = shared_library.MU_Calibration_calculateNoniusPosition(
            self.handle, c_void_p(), 0, int(unit), continuous)

        nonius_position_data_c = (c_double * number_of_samples)()
        number_of_samples = shared_library.MU_Calibration_calculateNoniusPosition(
            self.handle, nonius_position_data_c, number_of_samples, int(unit), continuous)
        r = [nonius_position_data_c[i] for i in range(number_of_samples)]
        return r

    def nonius_phase_margin_max(self) -> int:
        r = shared_library.MU_Calibration_noniusPhaseMarginMax(self.handle)
        return r

    def nonius_phase_margin_min(self) -> int:
        r = shared_library.MU_Calibration_noniusPhaseMarginMin(self.handle)
        return r

    def nonius_phase_range_limit(self) -> int:
        r = shared_library.MU_Calibration_noniusPhaseRangeLimit(self.handle)
        return r

    def nonius_upper_phase_margin(self) -> float:
        r = shared_library.MU_Calibration_noniusUpperPhaseMargin(self.handle)
        return r

    def nonius_lower_phase_margin(self) -> float:
        r = shared_library.MU_Calibration_noniusLowerPhaseMargin(self.handle)
        return r

    def single_turn_position(self,
                             unit: Unit,
                             continuous: bool = False,
                             nonius_track_offset_table: NoniusTrackOffsetTable = None) -> list:
        nonius_track_offset_table_p = None
        if nonius_track_offset_table is not None:
            nonius_track_offset_table_p = pointer(nonius_track_offset_table)

        number_of_samples = shared_library.MU_Calibration_calculateStPosition(
            self.handle, c_void_p(), 0, int(unit), continuous,
            nonius_track_offset_table_p)

        single_turn_data_c = (c_double * number_of_samples)()
        number_of_samples = shared_library.MU_Calibration_calculateStPosition(
            self.handle, single_turn_data_c, number_of_samples, int(unit), continuous,
            nonius_track_offset_table_p)
        r = [single_turn_data_c[i] for i in range(number_of_samples)]
        return r


shared_library.MU_Calibration_setCurrentAnalogTrackAdjustments.restype = c_bool
shared_library.MU_Calibration_setCurrentAnalogTrackAdjustments.argtypes = [
    c_void_p, POINTER(AnalogTrackAdjustments), POINTER(AnalogTrackAdjustments)]

shared_library.MU_Calibration_setCurrentNoniusTrackOffsetTable.restype = c_bool
shared_library.MU_Calibration_setCurrentNoniusTrackOffsetTable.argtypes = [
    c_void_p, POINTER(NoniusTrackOffsetTable)]

shared_library.MU_Calibration_adjustAnalogByAnalyzeResult.restype = c_bool
shared_library.MU_Calibration_adjustAnalogByAnalyzeResult.argtypes = [
    c_void_p, c_void_p]

shared_library.MU_Calibration_isAnalogAnalyzeResultAdjustable.restype = c_bool
shared_library.MU_Calibration_isAnalogAnalyzeResultAdjustable.argtypes = [
    c_void_p, c_void_p, c_char_p, c_size_t, c_uint]

shared_library.MU_Calibration_getAnalogMasterTrackAdjustments.argtypes = [
    c_void_p, POINTER(AnalogTrackAdjustments)]
shared_library.MU_Calibration_getAnalogNoniusTrackAdjustments.argtypes = [
    c_void_p, POINTER(AnalogTrackAdjustments)]
shared_library.MU_Calibration_getNoniusTrackOffsetTable.argtypes = [
    c_void_p, POINTER(NoniusTrackOffsetTable)]


class Calibration:
    """iC-MU Series Calibration"""

    @staticmethod
    def is_chip_revision_supported(revision_code: int) -> bool:
        r = shared_library.MU_isChipRevisionSupported(c_uint8(revision_code))
        return r

    def __init__(self, revision_code, calibration_handle_c=None):
        self.revision_code = revision_code
        if calibration_handle_c is not None:
            self.handle = calibration_handle_c
            return
        self.handle = shared_library.MU_createCalibration(c_uint8(revision_code))

    def __del__(self):
        shared_library.MU_Calibration_delete(self.handle)

    def preconfigure_number_of_master_periods(self, number_of_master_periods: int) -> bool:
        r = shared_library.MU_Calibration_preconfigureNumberOfMasterPeriods(
            self.handle, number_of_master_periods)
        return r

    def analyze_raw_data(self,
                         master_track_raw_data: list,
                         nonius_track_raw_data: list) -> AnalyzeResult:
        if int(len(master_track_raw_data)) != int(len(nonius_track_raw_data)):
            raise RuntimeError('The arguments master_track_raw_data and nonius_track_raw_data'
                               + 'must have the same length.')
        master_track_raw_data_c = (c_uint16 * len(master_track_raw_data))(*master_track_raw_data)
        nonius_track_raw_data_c = (c_uint16 * len(nonius_track_raw_data))(*nonius_track_raw_data)
        result_handle = shared_library.MU_Calibration_analyzeRawData(
            self.handle,
            master_track_raw_data_c,
            nonius_track_raw_data_c,
            int(len(master_track_raw_data)))
        if result_handle == None:
            raise Exception("Raw data are not analyzable")
        return AnalyzeResult(result_handle)

    def set_current_analog_track_adjustments(
            self, master_adjustments: AnalogTrackAdjustments,
            nonius_adjustments: AnalogTrackAdjustments) -> bool:
        r = shared_library.MU_Calibration_setCurrentAnalogTrackAdjustments(
            self.handle, pointer(master_adjustments), pointer(nonius_adjustments))
        return r

    def set_current_nonius_track_offset_table(
            self,
            nonius_track_offset_table: NoniusTrackOffsetTable) -> bool:
        r = shared_library.MU_Calibration_setCurrentNoniusTrackOffsetTable(
            self.handle, pointer(nonius_track_offset_table))
        return r

    def adjust_analog_by_analyze_result(self, analyze_result: AnalyzeResult) -> bool:
        r = shared_library.MU_Calibration_adjustAnalogByAnalyzeResult(
            self.handle, analyze_result.handle)
        return r

    def is_analog_analyze_result_adjustable(self, analyze_result: AnalyzeResult,
                                            adjustment_message_log_level: int) -> (bool, str):
        message_buffer_size = int(5 * 1024)
        message_buffer_c = create_string_buffer(message_buffer_size)
        r = shared_library.MU_Calibration_isAnalogAnalyzeResultAdjustable(
            self.handle, analyze_result.handle,
            message_buffer_c, message_buffer_size,
            adjustment_message_log_level)
        return r, message_buffer_c.value.decode('utf-8')

    def analog_master_track_adjustments(self) -> AnalogTrackAdjustments:
        analog_track_adjustments = AnalogTrackAdjustments()
        shared_library.MU_Calibration_getAnalogMasterTrackAdjustments(
            self.handle, pointer(analog_track_adjustments))
        return analog_track_adjustments

    def analog_nonius_track_adjustments(self) -> AnalogTrackAdjustments:
        analog_track_adjustments = AnalogTrackAdjustments()
        shared_library.MU_Calibration_getAnalogNoniusTrackAdjustments(
            self.handle, pointer(analog_track_adjustments))
        return analog_track_adjustments

    def nonius_track_offset_table(self) -> NoniusTrackOffsetTable:
        nonius_track_offset_table = NoniusTrackOffsetTable()
        shared_library.MU_Calibration_getNoniusTrackOffsetTable(
            self.handle, pointer(nonius_track_offset_table))
        return nonius_track_offset_table


class RelativeParameterChangesOfAnalogAdjustments(Structure):
    _fields_ = [("cosine_gain", c_int),
                ("sine_offset", c_int),
                ("cosine_offset", c_int),
                ("phase", c_int)]


shared_library.MU_getRelativeMasterTrackAdjustments.argtypes = [
    c_uint8, POINTER(AnalogTrackAdjustments), POINTER(AnalogTrackAdjustments),
    POINTER(RelativeParameterChangesOfAnalogAdjustments)]

shared_library.MU_getRelativeNoniusTrackAdjustments.argtypes = [
    c_uint8, POINTER(AnalogTrackAdjustments), POINTER(AnalogTrackAdjustments),
    POINTER(RelativeParameterChangesOfAnalogAdjustments)]


def relative_master_track_adjustments(
        revision_code: int,
        before: AnalogTrackAdjustments,
        after: AnalogTrackAdjustments) -> RelativeParameterChangesOfAnalogAdjustments:
    relative_parameter_changes_of_analog_adjustments = RelativeParameterChangesOfAnalogAdjustments()
    shared_library.MU_getRelativeMasterTrackAdjustments(
        revision_code, pointer(before),
        pointer(after),
        pointer(relative_parameter_changes_of_analog_adjustments))
    return relative_parameter_changes_of_analog_adjustments


def relative_nonius_track_adjustments(
        revision_code: int,
        before: AnalogTrackAdjustments,
        after: AnalogTrackAdjustments) -> RelativeParameterChangesOfAnalogAdjustments:
    relative_parameter_changes_of_analog_adjustments = RelativeParameterChangesOfAnalogAdjustments()
    shared_library.MU_getRelativeNoniusTrackAdjustments(
        revision_code, pointer(before),
        pointer(after),
        pointer(relative_parameter_changes_of_analog_adjustments))
    return relative_parameter_changes_of_analog_adjustments


shared_library.MU_getNoniusTrackOffsetTableParameters.argtypes = [
    POINTER(NoniusTrackOffsetTable), POINTER(NoniusTrackOffsetTableParameters)]


def nonius_track_offset_table_parameters(
        nonius_track_offset_table: NoniusTrackOffsetTable) -> NoniusTrackOffsetTableParameters:
    nonius_track_offset_table_parameters = NoniusTrackOffsetTableParameters()
    shared_library.MU_getNoniusTrackOffsetTableParameters(
        pointer(nonius_track_offset_table), pointer(nonius_track_offset_table_parameters))
    return nonius_track_offset_table_parameters


shared_library.MU_getNoniusTrackOffsetTableByParameters.argtypes = [
    POINTER(NoniusTrackOffsetTableParameters), POINTER(NoniusTrackOffsetTable)]


def nonius_track_offset_table_by_parameters(
        track_offset_table_parameters: NoniusTrackOffsetTableParameters) -> NoniusTrackOffsetTable:
    nonius_track_offset_table = NoniusTrackOffsetTable()
    shared_library.MU_getNoniusTrackOffsetTableByParameters(
        pointer(track_offset_table_parameters), pointer(nonius_track_offset_table))
    return nonius_track_offset_table
