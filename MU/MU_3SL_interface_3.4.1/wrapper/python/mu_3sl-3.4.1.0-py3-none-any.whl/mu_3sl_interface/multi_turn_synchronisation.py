# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from ctypes import *
import math
from typing import TypeVar, Union
from . import lib_mu_3sl_interface
from . import revisions
from . import units
from . import adjustment_message_log_level
from .calibration import Calibration


Revision = revisions.Revision
Unit = units.Unit
AdjustmentMessageLogLevel = adjustment_message_log_level.AdjustmentMessageLogLevel

shared_library = lib_mu_3sl_interface.shared_library


class MtSyncData(Structure):
    _fields_ = [("single_turn_position", c_uint32),
                ("internal_single_turn_position", c_uint32),
                ("normalized_external_multi_turn_sync_bits", c_uint32),
                ("normalized_internal_multi_turn_sync_bits", c_uint32),
                ("external_multi_turn_position", c_uint32),
                ("multi_turn_position", c_uint32),
                ("single_cycle_data", c_uint64)]

    def get_dict(self) -> dict:
        return dict((f, getattr(self, f)) for f, _ in self._fields_)



shared_library.MU_createMtSync.restype = c_void_p
shared_library.MU_createMtSync.argtypes = [c_void_p, c_size_t, c_bool]
shared_library.MU_MtSync_delete.argtypes = [c_void_p]
shared_library.MU_MtSync_calculatePosition.restype = c_size_t
shared_library.MU_MtSync_calculatePosition.argtypes = [c_void_p, c_void_p, c_void_p, c_size_t, c_uint8, c_uint64, c_int, c_bool]

shared_library.MU_MtSync_analyzeData.restype = c_void_p
shared_library.MU_MtSync_analyzeData.argtypes = [c_void_p, POINTER(MtSyncData), c_size_t]
shared_library.MU_MtAnalyzeResult_delete.argtypes = [c_void_p]

shared_library.MU_MtAnalyzeResult_optimalSpoMt.restype = c_uint8
shared_library.MU_MtAnalyzeResult_optimalSpoMt.argtypes = [c_void_p]

shared_library.MU_MtAnalyzeResult_calculateOffsetError.restype = c_size_t
shared_library.MU_MtAnalyzeResult_calculateOffsetError.argtypes = [c_void_p, c_void_p, c_size_t, c_uint8]
shared_library.MU_MtAnalyzeResult_maxOffsetError.restype = c_double
shared_library.MU_MtAnalyzeResult_maxOffsetError.argtypes = [c_void_p, c_uint8]
shared_library.MU_MtAnalyzeResult_minOffsetError.restype = c_double
shared_library.MU_MtAnalyzeResult_minOffsetError.argtypes = [c_void_p, c_uint8]
shared_library.MU_MtAnalyzeResult_offsetErrorRangeLimit.restype = c_double
shared_library.MU_MtAnalyzeResult_offsetErrorRangeLimit.argtypes = [c_void_p]
shared_library.MU_MtAnalyzeResult_upperOffsetErrorMargin.restype = c_double
shared_library.MU_MtAnalyzeResult_upperOffsetErrorMargin.argtypes = [c_void_p, c_uint8]
shared_library.MU_MtAnalyzeResult_lowerOffsetErrorMargin.restype = c_double
shared_library.MU_MtAnalyzeResult_lowerOffsetErrorMargin.argtypes = [c_void_p, c_uint8]



class MtAnalyzeResult:
    '''iC-MU Series Multi Turn Synchronization Analyze Result'''

    def __init__(self, multi_turn_analyze_result_handle: c_void_p):
        self.handle = multi_turn_analyze_result_handle

    def __del__(self):
        shared_library.MU_MtAnalyzeResult_delete(self.handle)

    def optimal_spo_mt(self) -> int:
        r = shared_library.MU_MtAnalyzeResult_optimalSpoMt(self.handle)
        return int(r)

    def calculate_offset_error(self, multi_turn_track_offset: int) -> list:
        number_of_samples = shared_library.MU_MtAnalyzeResult_calculateOffsetError(
            self.handle, c_void_p(), 0, multi_turn_track_offset)
        data_buffer_c = (c_double * number_of_samples)()
        number_of_samples = shared_library.MU_MtAnalyzeResult_calculateOffsetError(
            self.handle, data_buffer_c, number_of_samples, multi_turn_track_offset)
        r = [data_buffer_c[i] for i in range(number_of_samples)]
        return r

    def max_offset_error(self, multi_turn_track_offset: int) -> float:
        r = shared_library.MU_MtAnalyzeResult_maxOffsetError(
            self.handle, multi_turn_track_offset)
        return r

    def min_offset_error(self, multi_turn_track_offset: int) -> float:
        r = shared_library.MU_MtAnalyzeResult_minOffsetError(
            self.handle, multi_turn_track_offset)
        return r

    def offset_error_range_limit(self) -> float:
        r = shared_library.MU_MtAnalyzeResult_offsetErrorRangeLimit(self.handle)
        return r

    def upper_offset_error_margin(self, multi_turn_track_offset: int) -> float:
        r = shared_library.MU_MtAnalyzeResult_upperOffsetErrorMargin(
            self.handle, multi_turn_track_offset)
        return r

    def lower_offset_error_margin(self, multi_turn_track_offset: int) -> float:
        r = shared_library.MU_MtAnalyzeResult_lowerOffsetErrorMargin(
            self.handle, multi_turn_track_offset)
        return r



class MtSync:
    '''iC-MU Series Multi Turn Synchronization'''

    def __init__(self, calibration: Union[Calibration, c_void_p],
                 number_of_multi_turn_synchronization_bits: int = -1,
                 multi_turn_movement_is_reverse: bool = False):
        if not isinstance(calibration, Calibration):
            self.handle = calibration
            return

        self.handle = shared_library.MU_createMtSync(
            calibration.handle,
            number_of_multi_turn_synchronization_bits,
            multi_turn_movement_is_reverse)

    def __del__(self):
        shared_library.MU_MtSync_delete(self.handle)

    def analyze_data(self, synchronization_data: list) -> MtAnalyzeResult:
        synchronization_data_c = (MtSyncData * len(synchronization_data))(
            *synchronization_data)
        result_handle = shared_library.MU_MtSync_analyzeData(
            self.handle, synchronization_data_c, len(synchronization_data))
        return MtAnalyzeResult(result_handle)

    def calculate_position(self, synchronization_data: list,
                           multi_turn_track_offset: int, resolution: int,
                           unit: Unit, continuous: bool = False) -> list:
        synchronization_data_c = (MtSyncData * len(synchronization_data))(
            *synchronization_data)
        data_buffer_c = (c_double * len(synchronization_data))()
        number_of_samples = shared_library.MU_MtSync_calculatePosition(
            self.handle, data_buffer_c, synchronization_data_c, len(synchronization_data),
            multi_turn_track_offset, resolution, int(unit), continuous)
        r = [data_buffer_c[i] for i in range(number_of_samples)]
        return r
