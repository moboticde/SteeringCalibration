# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from . import commands
from . import config_data
from . import errors
from . import interfaces
from . import lib_mu_3sl_interface
from . import mode_a
from . import parameters
from . import revisions
from . import write_verify
from .calibration import *
from .multi_turn_synchronisation import *


shared_library = lib_mu_3sl_interface.shared_library
Library = lib_mu_3sl_interface.Library

Error = errors.Error
Interface = interfaces.Interface
Parameter = parameters.Parameter
Command = commands.Command
WriteVerify = write_verify.WriteVerify
ConfigData = config_data.ConfigData
Revision = revisions.Revision
ModeA = mode_a.ModeA

__doc__ = '''iC-MU Series Library for Python'''

version_suffix = ""
__version__ = lib_mu_3sl_interface.mu_3sl_interface_lib_version + version_suffix


class ReadSensStruct(Structure):
    _fields_ = [("mt", c_uint32),
                ("st", c_uint32),
                ("err", c_uint32),
                ("warn", c_uint32),
                ("rawMaster", c_uint32),
                ("rawNonius", c_uint32)]

    def get_dict(self) -> dict:
        return dict((f, getattr(self, f)) for f, _ in self._fields_)


class MU_Exception(Exception):
    def __init__(self, message, error_code):
        super().__init__(message)
        self.error_code = error_code


shared_library.MU_Open.restype = c_int
shared_library.MU_Open.argtypes = [POINTER(c_void_p)]
shared_library.MU_Close.restype = c_int
shared_library.MU_Close.argtypes = [c_void_p]
shared_library.MU_SetInterface.restype = c_int
shared_library.MU_SetInterface.argtypes = [c_void_p, c_int, c_char_p]
shared_library.MU_GetInterface.restype = c_int
shared_library.MU_GetInterface.argtypes = [c_void_p, POINTER(c_int)]
shared_library.MU_GetInterfaceInfo.restype = c_int
shared_library.MU_GetInterfaceInfo.argtypes = [c_void_p, c_int, c_char_p]
shared_library.MU_SetConfig.restype = c_int
shared_library.MU_SetConfig.argtypes = [c_void_p, c_int, c_uint32]
shared_library.MU_GetConfig.restype = c_int
shared_library.MU_GetConfig.argtypes = [c_void_p, c_int, POINTER(c_uint32)]

shared_library.MU_SwitchToBiss_ex.restype = c_int
shared_library.MU_SwitchToBiss_ex.argtypes = [c_void_p, POINTER(c_uint32), POINTER(c_bool)]
shared_library.MU_EnableGetMT.restype = c_int
shared_library.MU_EnableGetMT.argtypes = [c_void_p, POINTER(c_uint32), POINTER(c_bool)]
shared_library.MU_DisableGetMT.restype = c_int
shared_library.MU_DisableGetMT.argtypes = [c_void_p]
shared_library.MU_Initialize.restype = c_int
shared_library.MU_Initialize.argtypes = [c_void_p]

shared_library.MU_SetParam.restype = c_int
shared_library.MU_SetParam.argtypes = [c_void_p, c_int, c_uint32, c_uint32, c_int]
shared_library.MU_GetParam.restype = c_int
shared_library.MU_GetParam.argtypes = [c_void_p, c_int, POINTER(c_uint32), POINTER(c_uint32)]
shared_library.MU_IsParameterAvailableInUsedRevision.restype = c_int
shared_library.MU_IsParameterAvailableInUsedRevision.argtypes = [c_void_p, c_int, POINTER(c_bool)]

shared_library.MU_WriteParams.restype = c_int
shared_library.MU_WriteParams.argtypes = [c_void_p, c_bool, POINTER(c_bool)]
shared_library.MU_ReadParams.restype = c_int
shared_library.MU_ReadParams.argtypes = [c_void_p]
shared_library.MU_ReadStatus.restype = c_int
shared_library.MU_ReadStatus.argtypes = [c_void_p]
shared_library.MU_ReadGain.restype = c_int
shared_library.MU_ReadGain.argtypes = [c_void_p]

shared_library.MU_WriteEeprom.restype = c_int
shared_library.MU_WriteEeprom.argtypes = [c_void_p, c_int]
shared_library.MU_WriteCmdRegister.restype = c_int
shared_library.MU_WriteCmdRegister.argtypes = [c_void_p, c_int]
shared_library.MU_WriteSwitchCommand.restype = c_int
shared_library.MU_WriteSwitchCommand.argtypes = [c_void_p, c_uint32, c_uint32]

shared_library.MU_ReadSens.restype = c_int
shared_library.MU_ReadSens.argtypes = [c_void_p, POINTER(ReadSensStruct)]

shared_library.MU_SaveParams.restype = c_int
shared_library.MU_SaveParams.argtypes = [c_void_p, c_char_p]
shared_library.MU_ReadChipRevisionOfParameterFile.restype = c_int
shared_library.MU_ReadChipRevisionOfParameterFile.argtypes = [c_void_p, c_char_p, POINTER(c_uint8)]
shared_library.MU_LoadParams.restype = c_int
shared_library.MU_LoadParams.argtypes = [c_void_p, c_char_p]

shared_library.MU_GetLastError.restype = c_int
shared_library.MU_GetLastError.argtypes = [c_void_p, POINTER(c_int), POINTER(c_int), c_char_p]

shared_library.MU_CalcPRES_POS.restype = c_int
shared_library.MU_CalcPRES_POS.argtypes = [c_void_p, c_uint32, c_uint32, c_int]
shared_library.MU_GetPRES_POS.restype = c_int
shared_library.MU_GetPRES_POS.argtypes = [c_void_p, POINTER(c_uint32), POINTER(c_uint32)]

shared_library.MU_UseRevision.restype = c_int
shared_library.MU_UseRevision.argtypes = [c_void_p, c_uint8]
shared_library.MU_ValueOfUsedRevision.restype = c_int
shared_library.MU_ValueOfUsedRevision.argtypes = [c_void_p, POINTER(c_uint8)]
shared_library.MU_ReadChipRevision.restype = c_int
shared_library.MU_ReadChipRevision.argtypes = [c_void_p, POINTER(c_uint8)]

shared_library.MU_SetRegister.restype = c_int
shared_library.MU_SetRegister.argtypes = [c_void_p, c_uint32, c_uint32, c_int]
shared_library.MU_GetRegister.restype = c_int
shared_library.MU_GetRegister.argtypes = [c_void_p, c_uint32, POINTER(c_uint32)]
shared_library.MU_WriteRegister.restype = c_int
shared_library.MU_WriteRegister.argtypes = [c_void_p, c_uint32, POINTER(c_uint32),
                                            POINTER(c_uint32)]
shared_library.MU_ReadRegister.restype = c_int
shared_library.MU_ReadRegister.argtypes = [c_void_p, c_uint32, POINTER(c_uint32), POINTER(c_uint32)]
shared_library.MU_WriteRegisterSSI.restype = c_int
shared_library.MU_WriteRegisterSSI.argtypes = [c_void_p, c_uint32, POINTER(c_uint32),
                                               POINTER(c_uint32)]

shared_library.MU_getCalibration.restype = c_void_p
shared_library.MU_getCalibration.argtypes = [c_void_p]
shared_library.MU_setCalibration.restype = c_int
shared_library.MU_setCalibration.argtypes = [c_void_p, c_void_p]

shared_library.MU_acquireRawData.restype = c_int
shared_library.MU_acquireRawData.argtypes = [
    c_void_p,
    POINTER(c_uint16),
    POINTER(c_uint16),
    c_size_t,
    c_uint32,
    c_double,
    c_double
]

shared_library.MU_activateMtSyncConfig.restype = c_int
shared_library.MU_activateMtSyncConfig.argtypes = [c_void_p]
shared_library.MU_deactivateMtSyncConfig.restype = c_int
shared_library.MU_deactivateMtSyncConfig.argtypes = [c_void_p]
shared_library.MU_acquireMtSyncData.restype = c_int
shared_library.MU_acquireMtSyncData.argtypes = [
    c_void_p, POINTER(MtSyncData), c_size_t]

shared_library.MU_getMtSync.restype = c_void_p
shared_library.MU_getMtSync.argtypes = [c_void_p]
shared_library.MU_updateMtSync.restype = c_int
shared_library.MU_updateMtSync.argtypes = [c_void_p, c_void_p]

shared_library.MU_writeMtSyncSettings.restype = c_int
shared_library.MU_writeMtSyncSettings.argtypes = [c_void_p]
shared_library.MU_verifyMtSyncSettings.restype = c_int
shared_library.MU_verifyMtSyncSettings.argtypes = [c_void_p]


class MuHandle:
    """iC-MU Series Calibration Analyze Result"""

    def __init__(self):
        self.handle = c_void_p()
        e = shared_library.MU_Open(pointer(self.handle))
        self.error_check_raise_exception(e, [Error.OK], 'MU_Open')

    def __del__(self):
        self.set_interface(Interface.NO_INTERFACE)
        shared_library.MU_Close(self.handle)

    def set_interface(self, interface_type: int, interface_option: str = ''):
        interface_option_csp = c_char_p(interface_option.encode('ascii'))
        e = shared_library.MU_SetInterface(self.handle, interface_type, interface_option_csp)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SetInterface')

    def get_interface(self) -> dict:
        interface_type = (c_int)(0)
        e = shared_library.MU_GetInterface(self.handle, pointer(interface_type))
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetInterface')

        if Interface(int(interface_type.value)) == Interface.NO_INTERFACE:
            return {'type': Interface(int(interface_type.value))}

        serial_number_c = create_string_buffer(128)
        e = shared_library.MU_GetInterfaceInfo(self.handle, 0, serial_number_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetInterfaceInfo')

        driver_version_c = create_string_buffer(128)
        e = shared_library.MU_GetInterfaceInfo(self.handle, 1, driver_version_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetInterfaceInfo')

        return {'type': Interface(int(interface_type.value)),
                'serial_number': serial_number_c.value.decode('utf-8'),
                'driver_version': driver_version_c.value.decode('utf-8')}

    def set_config(self, config_data: int, value: int):
        e = shared_library.MU_SetConfig(self.handle, config_data, value)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SetConfig')

    def get_config(self, config_data: int) -> int:
        value_c = (c_uint32)()
        e = shared_library.MU_GetConfig(self.handle, config_data, value_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetConfig')
        return value_c.value

    def switch_to_biss(self) -> (int, int):
        mode_a_c = (c_uint32)()
        switched_c = (c_bool)()
        e = shared_library.MU_SwitchToBiss_ex(self.handle, pointer(mode_a_c), pointer(switched_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_SwitchToBiss_ex')
        return mode_a_c.value, switched_c.value

    def enable_get_mt(self) -> (int, bool):
        mode_a_c = (c_uint32)()
        switched_c = (c_bool)()
        e = shared_library.MU_EnableGetMT(self.handle, pointer(mode_a_c), pointer(switched_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_EnableGetMT')
        return mode_a_c.value, switched_c.value

    def disable_get_mt(self):
        e = shared_library.MU_DisableGetMT(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_DisableGetMT')

    def initialize(self):
        e = shared_library.MU_Initialize(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_Initialize')

    def set_parameter(self, parameter: Parameter, value: int):
        e = shared_library.MU_SetParam(self.handle, parameter.value, (value >> 32) & 0xffffffff,
                                       value & 0xffffffff,
                                       WriteVerify.SETONLY)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SetParam')

    def write_parameter(self, parameter: Parameter, value: int):
        e = shared_library.MU_SetParam(self.handle, parameter.value, (value >> 32) & 0xffffffff,
                                       value & 0xffffffff,
                                       WriteVerify.WRITE)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SetParam')

    def write_verify_parameter(self, parameter: Parameter, value: int):
        e = shared_library.MU_SetParam(self.handle, parameter.value, (value >> 32) & 0xffffffff,
                                       value & 0xffffffff,
                                       WriteVerify.VERIFY)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SetParam')

    def get_parameter(self, parameter: Parameter) -> int:
        value_h_c = (c_uint32)()
        value_l_c = (c_uint32)()
        e = shared_library.MU_GetParam(
            self.handle, parameter.value, pointer(value_h_c), pointer(value_l_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetParam')
        return int((value_h_c.value << 32) | value_l_c.value)

    def is_parameter_available_in_used_revision(self, parameter: Parameter) -> bool:
        in_revision = (c_bool)()
        e = shared_library.MU_IsParameterAvailableInUsedRevision(
            self.handle, parameter.value, pointer(in_revision))
        self.error_check_raise_exception(e, [Error.OK], 'MU_IsParameterAvailableInUsedRevision')
        return in_revision.value

    def write_parameters(self):
        e = shared_library.MU_WriteParams(self.handle, False, None)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteParams')

    def write_verify_parameters(self) -> list:
        number_of_registers = 256
        valid_c = (c_bool * number_of_registers)()
        for i in range(int(number_of_registers)):
            valid_c[i] = True
        e = shared_library.MU_WriteParams(self.handle, True, valid_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteParams')
        valid_registers = [valid_c[i] for i in range(int(number_of_registers))]
        return valid_registers

    def read_parameters(self):
        e = shared_library.MU_ReadParams(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_ReadParams')

    def read_status(self):
        e = shared_library.MU_ReadStatus(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_ReadStatus')

    def read_gain(self):
        e = shared_library.MU_ReadGain(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_ReadGain')

    def write_eeprom(self):
        e = shared_library.MU_WriteEeprom(self.handle, 0)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteEeprom')

    def write_cmd_register(self, command: Command):
        e = shared_library.MU_WriteCmdRegister(self.handle, command.value)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteCmdRegister')

    def write_switch_command(self, mode_a_new: int, rpl_new: int):
        e = shared_library.MU_WriteSwitchCommand(self.handle, mode_a_new, rpl_new)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteSwitchCommand')

    def read_sens(self) -> ReadSensStruct:
        data_c = ReadSensStruct()
        e = shared_library.MU_ReadSens(self.handle, pointer(data_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_ReadSens')
        return data_c

    def save_params(self, file_path: str):
        file_path_c = c_char_p(file_path.encode('ascii'))
        e = shared_library.MU_SaveParams(self.handle, file_path_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SaveParams')

    def read_chip_revision_of_parameter_file(self, file_path: str) -> int:
        file_path_c = c_char_p(file_path.encode('ascii'))
        revision_code_c = (c_uint8)()
        e = shared_library.MU_ReadChipRevisionOfParameterFile(
            self.handle, file_path_c, pointer(revision_code_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_ReadChipRevisionOfParameterFile')
        return revision_code_c.value

    def load_params(self, file_path: str):
        file_path_c = c_char_p(file_path.encode('ascii'))
        e = shared_library.MU_LoadParams(self.handle, file_path_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_LoadParams')

    def calc_pres_pos(self) -> int:
        value_h_c = (c_uint32)()
        value_l_c = (c_uint32)()
        e = shared_library.MU_CalcPRES_POS(
            self.handle, pointer(value_h_c), pointer(value_l_c), WriteVerify.SETONLY)
        self.error_check_raise_exception(e, [Error.OK], 'MU_CalcPRES_POS')
        return int((value_h_c.value << 32) | value_l_c.value)

    def calc_write_pres_pos(self) -> int:
        value_h_c = (c_uint32)()
        value_l_c = (c_uint32)()
        e = shared_library.MU_CalcPRES_POS(
            self.handle, pointer(value_h_c), pointer(value_l_c), WriteVerify.WRITE)
        self.error_check_raise_exception(e, [Error.OK], 'MU_CalcPRES_POS')
        return int((value_h_c.value << 32) | value_l_c.value)

    def calc_write_verify_pres_pos(self) -> int:
        value_h_c = (c_uint32)()
        value_l_c = (c_uint32)()
        e = shared_library.MU_CalcPRES_POS(
            self.handle, pointer(value_h_c), pointer(value_l_c), WriteVerify.VERIFY)
        self.error_check_raise_exception(e, [Error.OK], 'MU_CalcPRES_POS')
        return int((value_h_c.value << 32) | value_l_c.value)

    def get_pres_pos(self) -> int:
        value_h_c = (c_uint32)()
        value_l_c = (c_uint32)()
        e = shared_library.MU_GetPRES_POS(self.handle, pointer(value_h_c), pointer(value_l_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetPRES_POS')
        return int((value_h_c.value << 32) | value_l_c.value)

    def use_revision(self, revision_id: int):
        e = shared_library.MU_UseRevision(self.handle, revision_id)
        self.error_check_raise_exception(e, [Error.OK], 'MU_UseRevision')

    def value_of_used_revision(self) -> int:
        revision_id_c = (c_uint8)()
        e = shared_library.MU_ValueOfUsedRevision(self.handle, pointer(revision_id_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_ValueOfUsedRevision')
        return revision_id_c.value

    def read_chip_revision(self) -> int:
        revision_id_c = (c_uint8)()
        e = shared_library.MU_ReadChipRevision(self.handle, pointer(revision_id_c))
        self.error_check_raise_exception(e, [Error.OK, Error.CONTRADICTORY_REVISIONS,
                                             Error.UNKNOWN_REVISION, Error.UNSUPPORTED_REVISION],
                                         'MU_ReadChipRevision')
        return revision_id_c.value

    def set_register(self, address: int, value: int,
                     write_verify: WriteVerify = WriteVerify.SETONLY):
        e = shared_library.MU_SetRegister(self.handle, address, value, write_verify)
        self.error_check_raise_exception(e, [Error.OK], 'MU_SetRegister')
        return

    def get_register(self, address: int) -> int:
        value_c = (c_uint32)(0)
        e = shared_library.MU_GetRegister(self.handle, address, pointer(value_c))
        self.error_check_raise_exception(e, [Error.OK], 'MU_GetRegister')
        return int(value_c.value)

    def write_register(self, address: int, count: int, values: list) -> int:
        values_c = (c_uint32 * len(values))(*values)
        count_c = (c_uint32)(count)
        e = shared_library.MU_WriteRegister(self.handle, address, pointer(count_c), values_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteRegister')
        return int(count_c.value)

    def read_register(self, address: int, count: int) -> list:
        values_c = (c_uint32 * count)()
        count_c = (c_uint32)(count)
        e = shared_library.MU_ReadRegister(self.handle, address, pointer(count_c), values_c)
        values = [values_c[i] for i in range(int(count))]
        self.error_check_raise_exception(e, [Error.OK], 'MU_ReadRegister')
        return values

    def write_register_ssi(self, address: int, count: int, values: list) -> int:
        values_c = (c_uint32 * len(values))(*values)
        count_c = (c_uint32)(count)
        e = shared_library.MU_WriteRegisterSSI(self.handle, address, pointer(count_c), values_c)
        self.error_check_raise_exception(e, [Error.OK], 'MU_WriteRegisterSSI')
        return int(count_c.value)

    def get_calibration(self) -> Calibration:
        calibration_c = shared_library.MU_getCalibration(self.handle)
        if calibration_c is None:
            return None
        return Calibration(self.value_of_used_revision(), calibration_c)

    def set_calibration(self, calibration: Calibration):
        e = shared_library.MU_setCalibration(self.handle, calibration.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_setCalibration')

    def write_analog_calibration_settings(self):
        e = shared_library.MU_writeAnalogCalibrationSettings(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_writeAnalogCalibrationSettings')

    def verify_analog_calibration_settings(self):
        e = shared_library.MU_verifyAnalogCalibrationSettings(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_verifyAnalogCalibrationSettings')

    def write_nonius_calibration_settings(self):
        e = shared_library.MU_writeNoniusCalibrationSettings(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_writeNoniusCalibrationSettings')

    def verify_nonius_calibration_settings(self):
        e = shared_library.MU_verifyNoniusCalibrationSettings(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_verifyNoniusCalibrationSettings')

    def activate_calibration_configuration(self):
        e = shared_library.MU_activateCalibrationConfig(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_activateCalibrationConfig')

    def deactivate_calibration_configuration(self):
        e = shared_library.MU_deactivateCalibrationConfig(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_deactivateCalibrationConfig')

    def acquire_raw_data(self, number_of_samples: int, slave_id: int,
                         frame_cycle_time_s: float, clock_frequency_hz: float) -> (list, list):
        master_raw_data_c = (c_uint16 * number_of_samples)()
        nonius_raw_data_c = (c_uint16 * number_of_samples)()
        e = shared_library.MU_acquireRawData(
            self.handle,
            master_raw_data_c,
            nonius_raw_data_c,
            number_of_samples,
            slave_id,
            frame_cycle_time_s,
            clock_frequency_hz)
        self.error_check_raise_exception(e, [Error.OK], 'MU_acquireRawData')
        master_raw_data = [master_raw_data_c[i] for i in range(int(number_of_samples))]
        nonius_raw_data = [nonius_raw_data_c[i] for i in range(int(number_of_samples))]
        return (master_raw_data, nonius_raw_data)

    def activate_multi_turn_synchronization_configuration(self):
        e = shared_library.MU_activateMtSyncConfig(self.handle)
        self.error_check_raise_exception(e, [Error.OK],
                                         'MU_activateMtSyncConfig')

    def deactivate_multi_turn_synchronization_configuration(self):
        e = shared_library.MU_deactivateMtSyncConfig(self.handle)
        self.error_check_raise_exception(e, [Error.OK],
                                         'MU_deactivateMtSyncConfig')

    def acquire_multi_turn_synchronization_data(self, number_of_samples: int) -> list:
        synchronization_data_c_array = (MtSyncData * number_of_samples)()
        e = shared_library.MU_acquireMtSyncData(self.handle,
                                                synchronization_data_c_array,
                                                number_of_samples)
        self.error_check_raise_exception(e, [Error.OK], 'MU_acquireMtSyncData')
        return [synchronization_data_c_array[i] for i in range(int(number_of_samples))]


    def get_multi_turn_synchronization(self) -> MtSync:
        multi_turn_synchronization_c = shared_library.MU_getMtSync(self.handle)
        if multi_turn_synchronization_c is None:
            return None
        return MtSync(multi_turn_synchronization_c)

    def update_multi_turn_synchronization(self, multi_turn_analyze_result: MtAnalyzeResult):
        e = shared_library.MU_updateMtSync(
            self.handle, multi_turn_analyze_result.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_updateMtSync')

    def write_multi_turn_synchronization_settings(self):
        e = shared_library.MU_writeMtSyncSettings(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_writeMtSyncSettings')

    def verify_multi_turn_synchronization_settings(self):
        e = shared_library.MU_verifyMtSyncSettings(self.handle)
        self.error_check_raise_exception(e, [Error.OK], 'MU_verifyMtSyncSettings')

    def error_check_raise_exception(self, error_code, ok_codes: list, function_name):
        if error_code in ok_codes:
            return
        function_name_str = 'Library function call'
        if function_name is not None:
            function_name_str = function_name
        last_error = (c_int)()
        last_error_type = (c_int)()
        error_msg_c = create_string_buffer(128)
        shared_library.MU_GetLastError(
            self.handle, pointer(last_error), pointer(last_error_type), error_msg_c)
        raise MU_Exception('{:s} failed with {:s} ({:d}): "{:s}"'.format(
            function_name_str, str(Error(error_code)), error_code,
            error_msg_c.value.decode('utf-8')), error_code)


shared_library.MU_Interface_nextPossibleFrameCycleTime.restype = c_double
shared_library.MU_Interface_nextPossibleFrameCycleTime.argtypes = [c_int, c_double]
shared_library.MU_Interface_nearestPossibleFrameCycleTime.restype = c_double
shared_library.MU_Interface_nearestPossibleFrameCycleTime.argtypes = [c_int, c_double]
shared_library.MU_Interface_nextPossibleClockFreq.restype = c_double
shared_library.MU_Interface_nextPossibleClockFreq.argtypes = [c_int, c_double]
shared_library.MU_Interface_nearestPossibleClockFreq.restype = c_double
shared_library.MU_Interface_nearestPossibleClockFreq.argtypes = [c_int, c_double]


class InterfaceInfo:

    def __init__(self, interface_type: int):
        self.type = interface_type

    def next_possible_frame_cycle_time(self, current: float) -> float:
        return shared_library.MU_Interface_nextPossibleFrameCycleTime(self.type, current)

    def nearest_possible_frame_cycle_time(self, current: float) -> float:
        return shared_library.MU_Interface_nearestPossibleFrameCycleTime(self.type, current)

    def next_possible_clock_frequency(self, current: float) -> float:
        return shared_library.MU_Interface_nextPossibleClockFreq(self.type, current)

    def nearest_possible_clock_frequency(self, current: float) -> float:
        return shared_library.MU_Interface_nearestPossibleClockFreq(self.type, current)
