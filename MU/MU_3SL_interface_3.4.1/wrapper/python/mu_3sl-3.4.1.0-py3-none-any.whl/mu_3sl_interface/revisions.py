# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntEnum

class Revision(IntEnum):
    NONE = 0x00
    MU_Y = 0x05
    MU_Y1 = 0x06
    MU_Y2 = 0x07
    MU_Y2H = 0x07
    MU_Y3H = 0x08
    MU150_0 = 0x10
    MU150_1 = 0x11
    MU150_3 = 0x13
    MU200_0 = 0x20
