# -*- coding: utf-8 -*-

"""
Copyright 2022 iC-Haus GmbH

Software and its documentation is provided by iC-Haus GmbH or contributors "AS IS" and is
subject to the ZVEI General Conditions for the Supply of Products and Services with iC-Haus
amendments and the ZVEI Software clause with iC-Haus amendments (http://www.ichaus.de/EULA).
"""

from enum import IntEnum, unique, auto


@unique
class Error(IntEnum):
    OK = 0
    INVALID_HANDLE = auto()
    INTERFACEDRIVER_NOT_FOUND = auto()
    INTERFACE_NOT_FOUND = auto()
    INVALID_INTERFACE = auto()
    NO_INTERFACE_SELECTED = auto()
    INVALID_PARAMETER = auto()
    INVALID_ADDRESS = auto()
    INVALID_VALUE = auto()
    USB_ERROR = auto()
    FILE_NOT_FOUND = auto()
    INVALID_FILE = auto()
    SPI_ERROR = auto()
    SPI_DISMISS = auto()
    SPI_FAIL = auto()
    SPI_BUSY_TIMEOUT = auto()
    VERIFY_FAILED = auto()
    MASTERCOMM_FAILED = auto()
    BISSCOMM_FAILED = auto()
    INVALID_BISSMASTER = auto()
    USB_HIGHSPEED_WARNING = auto()
    FAST_ROTATION = auto()
    SLOW_ROTATION = auto()
    FILE_ACCESS_DENIED = auto()
    READPARAM_SSI = auto()
    SSIRING_ERROR = auto()
    SEMI_ROTATION = auto()
    BISS_REGERROR = auto()
    INTERNAL_CALIB_ERROR = auto()
    INVALID_CONFIGURATION = auto()
    CALIBRATION_FAILED = auto()
    ACQUISITION_FAILED = auto()
    GAIN_LIMIT = auto()
    OFFSET_LIMIT = auto()
    PHASE_LIMIT = auto()
    BAD_CAL_DATA = auto()
    I2C_COMM_FAILED = auto()
    USB_DATA_LOSS = auto()
    MT_SYNC_FAILED = auto()
    UNKNOWN_ERROR = auto()
    UNKNOWN_REVISION = auto()
    UNSUPPORTED_REVISION = auto()
    UNKNOWN_PARAMETER = auto()
    PARAMETER_NOT_IN_REVISION = auto()
    REVISION_NOT_SET = auto()
    UNSUPPORTED_CHIP = auto()
    CONTRADICTORY_REVISIONS = auto()
    FRAME_RATE_NOT_SUPPORTED = auto()
    CLOCK_FREQUENCY_NOT_SUPPORTED = auto()
    FRAME_CYCLE_TIME_TO_SHORT = auto()
